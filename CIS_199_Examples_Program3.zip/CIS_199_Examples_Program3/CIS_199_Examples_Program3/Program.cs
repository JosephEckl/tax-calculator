﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS_199_Examples_Program3
{
    class Program
    {
        

        static void Main(string[] args)
        {
            MarginalRateFor(10000);
            MarginalRateWhile(10000);

            /*
            TaxAmount(1000);
            TaxAmount(10000);
            TaxAmount(20000);
            TaxAmount(40000);
            TaxAmount(100000);
            */

            /*int x = 0;
            Console.WriteLine(phrase.Substring(x, 1));
            Console.WriteLine(phrase.Substring(x, x + 1));
            if(phrase.Substring(x, x + 1) == "a")
            {
                Console.WriteLine("yes");
            }
            */

            
        }

        public static void MarginalRateWhile(int income)
        {
            //int income = int.Parse(Console.ReadLine());

            int[] BaseT = { 9700, 39475, 84200, 160725, 204100, 510300 };

            double[] BaseR = { .1, .2, .3, .4 };

            //double[] BaseR = { .1, .12, .22, .24, .32, .35, .37 };

            int y = 0;
            bool found = false;

            while (y < BaseT.Length && !found)
            {
                if (income < BaseT[y])
                {
                    Console.WriteLine(BaseR[y]);
                    found = true;
                }

                y++;
            }
        }

        public static void MarginalRateFor(int income)
        {
            //int income = int.Parse(Console.ReadLine());
            

            int[] BaseT = { 9700, 39475, 84200, 160725, 204100, 510300 };

            double[] BaseR = { .1, .2, .3, .4 };

            //double[] BaseR = { .1, .12, .22, .24, .32, .35, .37 };

            for (int x = 0; x < BaseT.Length; x++)
            {
                if(income < BaseT[x])
                {
                    Console.WriteLine(BaseR[x]);
                    break;
                }
            }

            
        }

        public static void TaxAmount(int income)
        {
            //int income = int.Parse(Console.ReadLine());

            int[] BaseT = { 0, 9700, 39475, 84200 };

            double[] BaseR = { .1, .2, .3, .4 };

            double taxTotal = 0;

            for (int x = 0; x < BaseT.Length; x++)
            {
                if (income < BaseT[x + 1] || (x + 1) == BaseT.Length)
                {
                    taxTotal += (income - BaseT[x]) * BaseR[x];
                    break;
                }

                taxTotal += (BaseT[x + 1] - BaseT[x]) * BaseR[x];
            }
            Console.WriteLine($"Income: {income} Tax Amount: {taxTotal}");
        }

        public static void MarginalRateWhileSteps(int income)
        {
            //1) Make arrays of thresholds and rates
            int[] BaseT = { 9700, 39475, 84200, 160725, 204100, 510300 };
            double[] BaseR = { .1, .12, .22, .24, .32, .35, .37 };

            //2) Declare some variables to use in your loop

            //int y is our position counter
            int y = 0;
            //this boolean will keep track of whether or not we've found a place to stop
            bool found = false;

            //3) This is the basic while loop setup
            //It loops through every item in the array and does stuff each time, such as printing the current value
            while (y < BaseT.Length)
            {
                //do stuff

                y++;
            }

            //4) Now, we expand on the loop. We include an if statement to test if the income is less than the threshold we're currently looking at.
              
            while (y < BaseT.Length && !found)
            {
                //// if the income IS less than, we know we're in the right place and can stop
                if (income < BaseT[y])
                {
                    // we show the rate at the position we've stopped at
                    Console.WriteLine(BaseR[y]);
                    //changing the boolean to true stops the loop
                    found = true;
                }

                y++;
            }

            //this example starts at the beginning of the array and goes forward, but you could also start at the end and go backward of that makes more sense
            //here's what that version would look like, starting at step 2
            int z = BaseT.Length - 1;
            //bool found is still false
            while(z >= 0 && !found)
            {
                if(income >= BaseT[z])
                {
                    Console.WriteLine(BaseR[z]);
                    found = true;
                }

                z--;
            }
        }
    }
}